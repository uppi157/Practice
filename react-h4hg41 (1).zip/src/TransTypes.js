import React, { Component } from 'react';

class TransTypes extends Component {
  constructor() {
    super();
    this.state = {
      name: 'React'
    };
  }

  render() {
    return (
      <div>
        Transaction Types
      <div className="rTable">
	      { this.props.allTransTypes.map((transType, index) => 
          <div className="rTableRow" key={index}>
            <div className='rTableCell'><input type="checkbox" id='transType' name={transType}  onClick={this.props.checkboxClick}/></div>
            <div className='rTableCell'>{transType}</div>
          </div>
        )}
      </div>
      </div>
    );
  }
}
export default TransTypes;