import React, { Component } from 'react';

class Transactions extends Component {
  constructor() {
    super();
    this.state = {
      name: 'React'
    };
  }

  render() {
    return (
      <div className="rTable">
	      <div className="rTableRow">
          <div className='rTableHead'>Account Nnumber</div>
          <div  className='rTableHead'>Account Name</div>
          <div  className='rTableHead'>Currency</div>
          <div  className='rTableHead'>Amount</div>
          <div  className='rTableHead'>Transaction Type</div>
        </div>
        { this.props.totTrans.map( (transaction, index) => 
          <div className='rTableRow' key={index}>
            <div className="rTableCell">{transaction.account}</div>
            <div className="rTableCell">{transaction.accountName}</div>
            <div className="rTableCell">{transaction.currencyCode}</div>
            <div className="rTableCell">{transaction.amount}</div>
            <div className="rTableCell">{transaction.transactionType}</div>
          </div>
        )}
        </div>
     
    );
  }
}
export default Transactions;