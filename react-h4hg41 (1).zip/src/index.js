import React, { Component } from "react";
import { render } from "react-dom";
import "./style.css";
import AccountTypes from "./AccountTypes";
import TransTypes from "./TransTypes";
import Transactions from "./Transactions";
import data from "./data.json";
class App extends Component {
  constructor() {
    super();
    this.state = {
      transactions: [data],
      accTypes: [],
      transTypes: [],
      accFilter:[],
      transFilter:[],
      filters: {},
      filteredItems: []
 
    };
    this.handleChange = this.handleChange.bind(this);
  }
  distinctArr = (value,index,self) =>{
    return self.indexOf(value) === index;
  }
  componentDidMount() {
    console.log(data);
    let trans = this.state.transactions[0].transactions;
    let accTypes = trans.map((transaction) => transaction.accountName);
    let filteredacc = accTypes.filter((value,index,self) =>{
          return self.indexOf(value) === index;
        });
    this.setState({ accTypes:filteredacc});
    let transTypes = trans.map((transaction) => transaction.transactionType);
    this.setState({ transTypes: transTypes.filter((value,index,self) =>{
          return self.indexOf(value) === index;
        })});

  }
  
    handleChange =  evt => {
    const name = evt.target.name;
    const fltrnm = evt.target.id;
    const checked = evt.target.checked;

    this.setState(prevState => {
      const filters = {
        ...prevState.filters,
        [name]: checked
      };

      const activeFilterNames = Object.keys(filters).filter(
        filterName => filters[filterName]
      );
       const filteredItems = prevState.transactions[0].transactions.filter(item =>
        {
            return activeFilterNames.some(
             
              activeFilterName => {
                console.log(activeFilterName);
                 if(fltrnm == "accType"){
                   var chk = item.accountName
                 }
                 if(fltrnm == "transType")
                  var chk = item.transactionType;
                 return activeFilterName == chk;
                }
            );
        }
      );

      return {
        filters,
        filteredItems
      };
    });
  };
  render() {
    const items = this.state.filteredItems.length
      ? this.state.filteredItems
      : this.state.transactions[0].transactions;
    return (
      <div>
        <div className="pageTitle">Transactions</div>
        <div className="leftnav">
          <span>Filters</span>
          <AccountTypes  allAccTypes={this.state.accTypes} checkboxClick = {this.handleChange}/>
          <TransTypes allTransTypes={this.state.transTypes} checkboxClick = {this.handleChange}/>
        </div>
        <div className="mainContent">
          <Transactions totTrans={items} />
        </div>
      </div>
    );
  }
}

render(<App />, document.getElementById("root"));
