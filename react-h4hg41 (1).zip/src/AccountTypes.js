import React, { Component } from 'react';

class AccountTypes extends Component {
  constructor() {
    super();
    this.state = {
      name: 'React'
    };
  }

  render() {
    return (
      <div>
        Account Types
      <div className="rTable">
      { this.props.allAccTypes.map( (accType,index) => 
	      <div className="rTableRow" key={index}>
          <div className='rTableCell'><input type="checkbox" id='accType' name={accType}  onClick={this.props.checkboxClick}/></div>
          <div className='rTableCell'>{accType}</div>
        </div>
      )}
      </div>
      </div>
    );
  }
}
export default AccountTypes;